import 'package:flutter/material.dart';

class WeatherTab extends StatelessWidget {
  const WeatherTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Weather Tab Placeholder',
        style: TextStyle(fontSize: 18, color: Colors.grey),
      ),
    );
  }
}
