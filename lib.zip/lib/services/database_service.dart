import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import './local_storage_service.dart';
import '../models/product.dart';

class DatabaseService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // User Methods
  Future<void> createUser({
    required String uid,
    required String email,
    required String role,
    String? displayName,
    String? phoneNumber,
    String? profileImageUrl,
  }) async {
    await _db.collection('users').doc(uid).set({
      'uid': uid,
      'email': email,
      'role': role,
      'displayName': displayName,
      'phoneNumber': phoneNumber,
      'profileImageUrl': profileImageUrl,
      'createdAt': FieldValue.serverTimestamp(),
      'lastLoginAt': FieldValue.serverTimestamp(),
    });
  }

  // Cart Methods
  Future<void> addToCart({
    required String userId,
    required String itemId,
    required int quantity,
    required double price,
  }) async {
    await _db
        .collection('users')
        .doc(userId)
        .collection('cart')
        .doc(itemId)
        .set({
      'itemId': itemId,
      'quantity': quantity,
      'price': price,
      'addedAt': FieldValue.serverTimestamp(),
    });
  }

  // Category Methods
  Future<void> createCategory({
    required String name,
    String? imageUrl,
  }) async {
    await _db.collection('categories').add({
      'name': name,
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // Subcategory Methods
  Future<void> createSubcategory({
    required String categoryId,
    required String name,
    String? imageUrl,
  }) async {
    await _db
        .collection('categories')
        .doc(categoryId)
        .collection('subcategories')
        .add({
      'name': name,
      'imageUrl': imageUrl,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // Item Methods
  Future<void> createItem({
    required String categoryId,
    required String subcategoryId,
    required String name,
    required String description,
    required double price,
    required int quantity,
    required String unit,
    required String sellerUid,
    String? imageUrl,
  }) async {
    await _db
        .collection('categories')
        .doc(categoryId)
        .collection('subcategories')
        .doc(subcategoryId)
        .collection('items')
        .add({
      'name': name,
      'description': description,
      'price': price,
      'quantity': quantity,
      'unit': unit,
      'imageUrl': imageUrl,
      'sellerUid': sellerUid,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // Rating Methods
  Future<void> addRating({
    required String categoryId,
    required String subcategoryId,
    required String itemId,
    required String userId,
    required double rating,
    String? review,
  }) async {
    await _db
        .collection('categories')
        .doc(categoryId)
        .collection('subcategories')
        .doc(subcategoryId)
        .collection('items')
        .doc(itemId)
        .collection('ratings')
        .add({
      'userId': userId,
      'rating': rating,
      'review': review,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  // Order Methods
  Future<String> createOrder({
    required String buyerId,
    required String sellerId,
    required double totalAmount,
    required Map<String, dynamic> shippingAddress,
    required List<Map<String, dynamic>> items,
  }) async {
    final docRef = await _db.collection('orders').add({
      'buyerId': buyerId,
      'sellerId': sellerId,
      'status': 'pending',
      'totalAmount': totalAmount,
      'shippingAddress': shippingAddress,
      'items': items,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return docRef.id;
  }

  // Transaction Methods
  Future<void> createTransaction({
    required String orderId,
    required String buyerId,
    required String sellerId,
    required double amount,
    required String paymentMethod,
  }) async {
    await _db.collection('transactions').add({
      'orderId': orderId,
      'buyerId': buyerId,
      'sellerId': sellerId,
      'amount': amount,
      'status': 'pending',
      'paymentMethod': paymentMethod,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  Future<Product?> getProduct(String productId) async {
    try {
      final doc = await _db.collection('products').doc(productId).get();
      if (doc.exists && doc.data() != null) {
        return Product.fromMap({'id': doc.id, ...doc.data()!});
      }
      return null;
    } catch (e) {
      throw Exception('Failed to get product: $e');
    }
  }

  Future<void> addProduct(Product product, File? imageFile) async {
    try {
      if (imageFile != null) {
        final fileName =
            '${DateTime.now().millisecondsSinceEpoch}_${product.id}.jpg';
        // saveImage expects folder, filename and File -> returns saved file path
        final savedPath = await LocalStorageService.saveImage(
            'products', fileName, imageFile);
        product.localImagePath = savedPath;
      }

      await _db.collection('products').doc(product.id).set(product.toMap());
    } catch (e) {
      throw Exception('Failed to add product: $e');
    }
  }

  Future<void> deleteProduct(String productId) async {
    try {
      final product = await getProduct(productId);
      if (product?.localImagePath != null) {
        await LocalStorageService.deleteImage(product!.localImagePath!);
      }
      await _db.collection('products').doc(productId).delete();
    } catch (e) {
      throw Exception('Failed to delete product: $e');
    }
  }
}
