import 'dart:io';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/storage_service.dart';
import '../../services/local_storage_service.dart';

class SellerSubcategoryScreen extends StatefulWidget {
  final String category;

  const SellerSubcategoryScreen({
    super.key,
    required this.category,
  });

  @override
  State<SellerSubcategoryScreen> createState() =>
      _SellerSubcategoryScreenState();
}

class _SellerSubcategoryScreenState extends State<SellerSubcategoryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _subcategoryController = TextEditingController();
  final _storageService = StorageService();
  File? _selectedImage;

  @override
  void dispose() {
    _subcategoryController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final File? image = await _storageService.pickImage();
    if (image != null) {
      setState(() {
        _selectedImage = image;
      });
    }
  }

  Future<void> _addSubcategory() async {
    if (!_formKey.currentState!.validate()) return;

    try {
      final subcategoryName = _subcategoryController.text.trim();
      String? imagePath;

      if (_selectedImage != null) {
        final fileName =
            '${DateTime.now().millisecondsSinceEpoch}_${widget.category}_$subcategoryName.jpg';
        imagePath = await LocalStorageService.saveImage(
            'subcategories', fileName, _selectedImage!);
      }

      // Add the subcategory to Firestore
      await FirebaseFirestore.instance
          .collection('categories')
          .doc(widget.category)
          .collection('subcategories')
          .doc(subcategoryName.toLowerCase())
          .set({
        'name': subcategoryName,
        'imagePath': imagePath,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Subcategory added successfully')),
        );
        _subcategoryController.clear();
        Navigator.pop(context); // Close the dialog
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _showAddSubcategoryDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Container(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Add Subcategory',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF17904A),
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        height: 180,
                        decoration: BoxDecoration(
                          color: Colors.grey[100],
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Color(0xFF17904A).withOpacity(0.5),
                            width: 2,
                            style: BorderStyle.solid,
                          ),
                        ),
                        child: _selectedImage != null
                            ? Stack(
                                alignment: Alignment.topRight,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.file(
                                      _selectedImage!,
                                      height: 180,
                                      width: double.infinity,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.9),
                                      shape: BoxShape.circle,
                                    ),
                                    child: IconButton(
                                      icon: Icon(Icons.edit,
                                          color: Color(0xFF17904A)),
                                      onPressed: _pickImage,
                                    ),
                                  ),
                                ],
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.add_photo_alternate_outlined,
                                    size: 50,
                                    color: Color(0xFF17904A),
                                  ),
                                  SizedBox(height: 12),
                                  Text(
                                    'Add Subcategory Image',
                                    style: TextStyle(
                                      color: Color(0xFF17904A),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Tap to select',
                                    style: TextStyle(
                                      color: Colors.grey[600],
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                    SizedBox(height: 20),
                    TextFormField(
                      controller: _subcategoryController,
                      decoration: InputDecoration(
                        labelText: 'Subcategory Name',
                        hintText: 'Enter the subcategory name',
                        prefixIcon:
                            Icon(Icons.category, color: Color(0xFF17904A)),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Color(0xFF17904A)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide:
                              BorderSide(color: Color(0xFF17904A), width: 2),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(
                              color: Color(0xFF17904A).withOpacity(0.5)),
                        ),
                        filled: true,
                        fillColor: Colors.grey[50],
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter a subcategory name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 24),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(
                              padding: EdgeInsets.symmetric(vertical: 16),
                              side: BorderSide(color: Color(0xFF17904A)),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(
                              'Cancel',
                              style: TextStyle(color: Color(0xFF17904A)),
                            ),
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: _addSubcategory,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF17904A),
                              padding: EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text('Add'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper to render either local file image or network image with fallback
  Widget _buildSubcategoryImage(String? imagePath,
      {BoxFit fit = BoxFit.cover}) {
    if (imagePath == null || imagePath.isEmpty) {
      return Image.asset(
        'assets/images/placeholder.png',
        fit: fit,
      );
    }

    return FutureBuilder<File?>(
      future: LocalStorageService.getImage(imagePath),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (!snapshot.hasData || snapshot.data == null) {
          return Image.asset(
            'assets/images/placeholder.png',
            fit: fit,
          );
        }
        return Image.file(
          snapshot.data!,
          fit: fit,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.category} Categories'),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search for products',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[200],
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('categories')
                  .doc(widget.category)
                  .collection('subcategories')
                  .orderBy('name')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                }

                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final subcategories = snapshot.data!.docs;

                return GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                  ),
                  padding: const EdgeInsets.all(16),
                  itemCount: subcategories.length + 1,
                  itemBuilder: (context, index) {
                    if (index == 0) {
                      return Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: InkWell(
                          onTap: _showAddSubcategoryDialog,
                          borderRadius: BorderRadius.circular(12),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  color: Colors.grey[200],
                                  shape: BoxShape.circle,
                                ),
                                child: const Icon(Icons.add_circle_outline,
                                    size: 40, color: Color(0xFF17904A)),
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                'Add',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    final doc = subcategories[index - 1];
                    final data = doc.data() as Map<String, dynamic>;
                    return InkWell(
                      onTap: () {
                        Navigator.pushNamed(
                          context,
                          '/seller/items',
                          arguments: {
                            'category': widget.category,
                            'subcategory': doc.id,
                          },
                        );
                      },
                      child: Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: const BorderRadius.vertical(
                                  top: Radius.circular(12),
                                ),
                                child: _buildSubcategoryImage(
                                  (data['imagePath'] as String?),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    data['name'] ?? doc.id,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  StreamBuilder<QuerySnapshot>(
                                    stream: FirebaseFirestore.instance
                                        .collection('categories')
                                        .doc(widget.category)
                                        .collection('subcategories')
                                        .doc(doc.id)
                                        .collection('items')
                                        .snapshots(),
                                    builder: (context, itemSnapshot) {
                                      if (itemSnapshot.hasError) {
                                        // Check for missing index error
                                        final error =
                                            itemSnapshot.error.toString();
                                        if (error.contains(
                                            'Failed to get documents: [cloud_firestore/failed-precondition]')) {
                                          // Show dialog with index creation link
                                          WidgetsBinding.instance
                                              .addPostFrameCallback((_) {
                                            showDialog(
                                              context: context,
                                              builder: (context) => AlertDialog(
                                                title: const Text(
                                                    'Index Required'),
                                                content: const Text(
                                                    'This query requires an index. Click Create to set it up.'),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () =>
                                                        Navigator.pop(context),
                                                    child: const Text('Cancel'),
                                                  ),
                                                  TextButton(
                                                    onPressed: () async {
                                                      final url =
                                                          error.substring(
                                                        error.indexOf('https'),
                                                        error.indexOf(']'),
                                                      );
                                                      // Open index creation URL (implement URL launcher)
                                                      print(
                                                          'Create index at: $url');
                                                      Navigator.pop(context);
                                                    },
                                                    child: const Text(
                                                        'Create Index'),
                                                  ),
                                                ],
                                              ),
                                            );
                                          });
                                        }
                                        return const Text(
                                            'Error loading items');
                                      }

                                      if (!itemSnapshot.hasData) {
                                        return const Text('Loading...');
                                      }
                                      final itemCount =
                                          itemSnapshot.data!.docs.length;
                                      return Text(
                                        '$itemCount items',
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 14,
                                        ),
                                      );
                                    },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
