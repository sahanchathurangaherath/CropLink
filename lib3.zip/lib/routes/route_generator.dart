// lib/routes/route_generator.dart
import 'package:flutter/material.dart';

import '../screens/welcome.dart';
import '../screens/home.dart';
import '../screens/auth/auth_gate.dart';
import '../screens/auth/sign_in_screen.dart';
import '../screens/auth/sign_up_screen.dart';
import '../screens/buyer/buyer_items_screen.dart';
import '../screens/seller/seller_items_screen.dart';
import '../screens/post_item.dart';
import '../screens/seller_item_page.dart';

import 'app_routes.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    final name = settings.name;
    final args = settings.arguments;

    switch (name) {
      // Auth / entry
      case AppRoutes.welcome:
        return MaterialPageRoute(builder: (_) => const WelcomeScreen());
      case AppRoutes.authGate:
        return MaterialPageRoute(builder: (_) => const AuthGate());
      case AppRoutes.signIn:
        return MaterialPageRoute(builder: (_) => const SignInScreen());
      case AppRoutes.signUp:
        return MaterialPageRoute(builder: (_) => const SignUpScreen());

      // Main/home
      case AppRoutes.home:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      // Posting / items
      case AppRoutes.postItem:
        return MaterialPageRoute(builder: (_) => const PostItemScreen());

      case AppRoutes.sellerItemPage:
        if (args is String && args.isNotEmpty) {
          return MaterialPageRoute(
            builder: (_) => SellerItemPage(category: args),
          );
        }
        return _badArgs('Expected a non-empty String category for $name');

      // Category listings
      case AppRoutes.buyerItems:
        if (args is String && args.isNotEmpty) {
          return MaterialPageRoute(
            builder: (_) => BuyerItemsScreen(category: args),
          );
        }
        return _badArgs('Expected a non-empty String category for $name');

      case AppRoutes.sellerItems:
        if (args is String && args.isNotEmpty) {
          return MaterialPageRoute(
            builder: (_) => SellerItemsScreen(category: args),
          );
        }
        return _badArgs('Expected a non-empty String category for $name');

      // Tab “routes” (optional): send them to HomeScreen.
      case AppRoutes.catalog:
      case AppRoutes.weather:
      case AppRoutes.news:
      case AppRoutes.cart:
      case AppRoutes.account:
        return MaterialPageRoute(builder: (_) => const HomeScreen());

      default:
        return _notFound(name);
    }
  }

  static Route<dynamic> _notFound(String? name) {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Not found')),
        body: Center(child: Text('Route not found: $name')),
      ),
    );
  }

  static Route<dynamic> _badArgs(String message) {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Bad arguments')),
        body: Center(child: Text(message)),
      ),
    );
  }
}
