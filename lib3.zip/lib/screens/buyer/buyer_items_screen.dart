import 'package:flutter/material.dart';
import '../../models/category_items.dart';

class BuyerItemsScreen extends StatelessWidget {
  final String category;

  const BuyerItemsScreen({
    super.key,
    required this.category,
  });

  @override
  Widget build(BuildContext context) {
    final items = CategoryItems.getItemsForCategory(category);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF17904A),
        title: Text(category),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // TODO: Implement search
            },
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.75,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemCount: items.length,
        itemBuilder: (context, index) {
          return _ItemCard(
            name: items[index],
            quantity: '500g',
            priceRange: 'Rs.240-280',
            onTap: () {
              // TODO: Navigate to item detail
            },
          );
        },
      ),
    );
  }
}

class _ItemCard extends StatelessWidget {
  final String name;
  final String quantity;
  final String priceRange;
  final VoidCallback onTap;

  const _ItemCard({
    required this.name,
    required this.quantity,
    required this.priceRange,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Center(
                  child: Image.asset(
                    'assets/images/placeholder.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                name,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              Text(
                quantity,
                style: const TextStyle(color: Colors.grey),
              ),
              Text(
                priceRange,
                style: const TextStyle(
                  color: Color(0xFF17904A),
                  fontWeight: FontWeight.bold,
                ),
              ),
              ElevatedButton(
                onPressed: () {
                  // TODO: Add to cart
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF17904A),
                  minimumSize: const Size(double.infinity, 36),
                ),
                child: const Text(
                  'ADD',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
